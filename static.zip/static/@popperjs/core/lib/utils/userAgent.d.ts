export default function getUAString(): string;
