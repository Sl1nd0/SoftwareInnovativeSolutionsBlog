export default function getAltAxis(axis: "x" | "y"): "x" | "y";
